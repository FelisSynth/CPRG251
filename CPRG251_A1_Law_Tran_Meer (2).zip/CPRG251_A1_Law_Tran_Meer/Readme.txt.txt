CPRG251 Assignment 1 - ABC Book Company Management System

The program is a system to manage a series of book by ABC Book Company.
It allows checking out books, search books by title, display specific types of books, and display a list of random books.
The program implements the uses of ArrayList to store the book records, and filter, sort, displays and interact based on the users' needs.

Date: Feb 11 2022
Author: Dylano Van der Meer, Joshua Law, Trung Hieu Tran

To run the program, invoke the Menu() method located in Tester.java to start the program

**Please ensure you reformat the directory to suit your needs**