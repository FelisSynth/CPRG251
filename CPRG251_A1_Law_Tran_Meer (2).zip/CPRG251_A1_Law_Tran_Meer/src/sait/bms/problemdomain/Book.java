package sait.bms.problemdomain;
import java.util.*;
/**
 * The superclass for 4 other book types
 *
 * Contains the constructor for the list of books, methods to
 * respond to the user options, and formatted display of books.
 *
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */
public abstract class Book 
{

	private ArrayList<Book> allBookList = new ArrayList<>();
	private String isbn;
	private String callNumber;
	private int available;
	private int total;
	private String title;

	/**
	 * default constructor for Book object
	 */
	public Book()
	{
		
	}

	/**
	 * Book constructor with attributes as parameters
	 *
	 * @param isbn the book's isbn
	 * @param callNumber call number for a book
	 * @param available the number of books available
	 * @param total the total number of books
	 * @param title the title of the book
	 */
	public Book(String isbn, String callNumber,int available,int total,String title)
	{
		this.isbn = isbn;
		this.callNumber = callNumber;
		this.available = available;
		this.total = total;
		this.title = title;
		
	}
	/**
	 * Method to get a list of all books
	 *
	 * @return the ArrayList of books
	 */
	public ArrayList<Book> getAllBookList() {
		return allBookList;
	}

	/**
	 * Method to write and update the book list
	 *
	 * @param allBookList the ArrayList of books
	 */
	public void setAllBookList(ArrayList<Book> allBookList) {
		this.allBookList = allBookList;
	}

	/**
	 * getter method for ISBN
	 *
	 * @return ISBN
	 */
	public String getIsbn() {
		return isbn;
	}

	/**
	 * setter method for ISBN
	 *
	 * @param isbn ISBN
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	/**
	 * getter method for Call number
	 *
	 * @return Call number
	 */
	public String getCallNumber() {
		return callNumber;
	}

	/**
	 * setter method for Call number
	 *
	 * @param callNumber  Call number
	 */
	public void setCallNumber(String callNumber) {
		this.callNumber = callNumber;
	}

	/**
	 * getter method for available number of books
	 *
	 * @return available number of books
	 */
	public int getAvailable() {
		return available;
	}

	/**
	 * setter method for available number of books
	 *
	 * @param available  available number of books
	 */
	public void setAvailable(int available) {
		this.available = available;
	}

	/**
	 * getter method for total number of books
	 *
	 * @return total number of books
	 */
	public int getTotal() {
		return total;
	}

	/**
	 * setter method for total number of books
	 *
	 * @param total total number of books
	 */
	public void setTotal(int total) {
		this.total = total;
	}

	/**
	 * getter method for book title
	 *
	 * @return book title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * setter method for book title
	 *
	 * @param title book title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Method to check out a book from ISBN
	 *
	 * The method is invoked when the user chooses the 1st option in the main menu
	 * The method takes the inputted ISBN and checks if it matches any entries,
	 * then check for its availability. If the book is available, the book is checked
	 * out along with contact information.
	 */
	public void checkoutBook()
	{
		Scanner MenuOneUserInput = new Scanner(System.in);
		System.out.print("Enter the ISBN of book: ");
		String searchISBN = MenuOneUserInput.nextLine();
		System.out.println("");
		int count;
		Book checkoutBook;
		for(count = 0; count < getAllBookList().size(); count ++)
		{
			
			if(getAllBookList().get(count).getIsbn().equals(searchISBN) && !searchISBN.equals(""))
			{
				checkoutBook = getAllBookList().get(count);
				
				if(checkoutBook.getAvailable() > 0 && searchISBN.isEmpty() == false)
				{
					System.out.println("");
					System.out.println("The Book \"" + checkoutBook.getTitle() + "\" has been checked out.\nIt can be located using call number: " + checkoutBook.getCallNumber());
					break;
				}
				else 
				{
					System.out.printf("Book is unavailable at the moment!\nPlease check again another time.");
				}
				
				checkoutBook.setAvailable(checkoutBook.getAvailable() - 1);
			}
		}
	}
	
}
