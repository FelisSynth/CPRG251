package sait.bms.problemdomain;
import java.util.*;
/**
 * One of the 4 subclasses of the Book class
 *
 * Contains constructor for list of Children's Books, getters, setters
 * and method to display books in a readable format.
 *
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */
public class ChildrensBook extends Book
{
	private ArrayList<ChildrensBook> childrensBookList= new ArrayList<>();
	private String authors;
	private String format;

	/**
	 * default constructor for Children's Book object
	 */
	public ChildrensBook() 
	{
	
	}

	/**
	 * Book constructor with attributes as parameters
	 *
	 * @param isbn the book's isbn
	 * @param callNumber call number for a book
	 * @param available the number of books available
	 * @param total the total number of books
	 * @param title the title of the book
	 * @param publisher publisher of the book
	 * @param format the type of children's book
	 */
	public ChildrensBook(String isbn, String callNumber, int available, int total, String title,String publisher, String format) 
	{
		super(isbn, callNumber, available, total, title);
		this.authors = publisher;
		this.format = format;
	}

	/**
	 * Method to return list of Children's book
	 *
	 * @return list of Children's book
	 */
	public ArrayList<ChildrensBook> getChildrensBookList() {
		return childrensBookList;
	}

	/**
	 * Method to write and update the Children's book list
	 *
	 * @param childrensBook list of Children's book
	 */
	public void setchildrensBookList(ChildrensBook childrensBook) {
		this.childrensBookList.add(childrensBook);
	}

	/**
	 * getter method for book author
	 *
	 * @return book author
	 */
	public String getAuthors() {
		return authors;
	}

	/**
	 * setter method for book author
	 *
	 * @param authors book author
	 */
	public void setAuthors(String authors) {
		this.authors = authors;
	}

	/**
	 * getter method for book format
	 *
	 * @return format
	 */
	public String getFormat() {
		return format;
	}

	/**
	 * setter method for book format
	 *
	 * @param format book format
	 */
	public void setFormat(String format) {
		this.format = format;
	}

	/**
	 * Method to display Children's books
	 *
	 * @return formatted display of Children's book
	 */
	public String toString()
	{
		if(format.equalsIgnoreCase("P")) 
		{
			format = "Picture";
		}
		else if(format.equalsIgnoreCase("E"))
		{
			format = "Early Readers";
		}
		else if(format.equalsIgnoreCase("C"))
		{
			format = "Chapter";
		}
		
		return String.format("%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n","ISBN:", super.getIsbn(),"Call Number:",super.getCallNumber(),"Available:",super.getAvailable(),"Total:",super.getTotal(),"Title:",super.getTitle(),"Author(s):",authors,"format:",format);
	}
	
}
