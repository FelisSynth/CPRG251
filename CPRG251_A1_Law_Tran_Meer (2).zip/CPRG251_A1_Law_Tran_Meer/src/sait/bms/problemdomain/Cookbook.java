package sait.bms.problemdomain;
import java.util.*;

/**
 * One of the 4 subclasses of the Book class
 *
 * Contains constructor for list of Cookbooks, getters, setters
 * and method to display books in a readable format.
 *
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */
public class Cookbook extends Book
{
	private ArrayList<Cookbook> cookbookList= new ArrayList<>();
	private String publisher;
	private String diet;

	/**
	 * default constructor for Cookbook object
	 */
	public Cookbook() 
	{
		
	}

	/**
	 * Book constructor with attributes as parameters
	 *
	 * @param isbn the book's isbn
	 * @param callNumber call number for a book
	 * @param available the number of books available
	 * @param total the total number of books
	 * @param title the title of the book
	 * @param publisher publisher of the book
	 * @param diet the type of Cookbook diet
	 */
	public Cookbook(String isbn, String callNumber, int available, int total, String title,String publisher, String diet) 
	{
		super(isbn, callNumber, available, total, title);
		this.publisher = publisher;
		this.diet = diet;
	}

	/**
	 * Method to return list of Cookbook
	 *
	 * @return list of Cookbook
	 */
	public ArrayList<Cookbook> getCookbookList() {
		return cookbookList;
	}

	/**
	 * Method to write and update the Cookbook list
	 *
	 * @param cookbook list of Cookbook
	 */
	public void setCookbookList(Cookbook cookbook) {
		this.cookbookList.add(cookbook) ;
	}

	/**
	 * getter method for book publisher
	 *
	 * @return book publisher
	 */
	public String getPublisher() {
		return publisher;
	}

	/**
	 * setter method for book publisher
	 *
	 * @param publisher book publisher
	 */
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	/**
	 * getter method for book diet
	 *
	 * @return diet
	 */
	public String getDiet() {
		return diet;
	}

	/**
	 * setter method for book diet
	 *
	 * @param diet book diet
	 */
	public void setDiet(String diet) {
		this.diet = diet;
	}

	/**
	 * Method to display Cookbooks
	 *
	 * @return formatted display of Cookbook
	 */
	public String toString()
	{
		if(diet.equalsIgnoreCase("D")) 
		{
			diet = "Diabetic";
		}
		else if(diet.equalsIgnoreCase("V"))
		{
			diet = "Vegetarian";
		}
		else if(diet.equalsIgnoreCase("G"))
		{
			diet = "Gluten-Free";
		}
		else if(diet.equalsIgnoreCase("I"))
		{
			diet = "International";
		}
		else
		{
			diet = "None";
		}
		return String.format("%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n","ISBN:", super.getIsbn(),"Call Number:",super.getCallNumber(),"Available:",super.getAvailable(),"Total:",super.getTotal(),"Title:",super.getTitle(),"publisher:",publisher,"Diet:",diet);
	}

}
