package sait.bms.problemdomain;

/**
 * Main method
 *
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */
public class Main extends Book{

	
	
	public Main() 
	{

	}
	
	
}
