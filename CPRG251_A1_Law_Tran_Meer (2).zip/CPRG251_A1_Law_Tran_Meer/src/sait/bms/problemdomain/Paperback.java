package sait.bms.problemdomain;
import java.util.*;

/**
 * One of the 4 subclasses of the Book class
 *
 * Contains constructor for list of Paperbacks, getters, setters
 * and method to display books in a readable format.
 *
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */
public class Paperback extends Book
{
	private ArrayList<Paperback> paperbackList= new ArrayList<Paperback>();
    private String author;
    private String year;
    private String genre;

    /**
     * default constructor for Paperback object
     */
    public Paperback() 
    {

    }

    /**
     * Book constructor with attributes as parameters
     *
     * @param isbn the book's isbn
     * @param callNumber call number for a book
     * @param available the number of books available
     * @param total the total number of books
     * @param title the title of the book
     * @param author author of the book
     * @param year the year the Paperback was written
     * @param genre the Paperback genre
     */
    public Paperback(String isbn, String callNumber, int available, int total, String title,String author, String year, String genre) 
    {
        super(isbn, callNumber, available, total, title);
        this.author = author;
        this.year = year;
        this.genre = genre;
    }


    /**
     * Method to return list of Paperback
     *
     * @return list of Paperback
     */
    public ArrayList<Paperback> getPaperbackList() {
        return paperbackList;
    }

    /**
     * Method to write and update the Paperback list
     *
     * @param paperback list of Paperback
     */
    public void setPaperbackList(Paperback paperback) {
        this.paperbackList.add(paperback);
    }

    /**
     * getter method for book author
     *
     * @return book author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * setter method for book author
     *
     * @param author book author
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * getter method for book written date (year)
     *
     * @return book written date (year)
     */
    public String getYear() {
        return year;
    }

    /**
     * setter method for book written date (year)
     *
     * @param year book written date (year)
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * getter method for book genre
     *
     * @return genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * setter method for book genre
     *
     * @param genre book genre
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * Method to display Paperbacks
     *
     * @return formatted display of Paperback
     */
    public String toString()
    {
        if(genre.equalsIgnoreCase("A")) 
        {
            genre = "Adventure";
        }
        else if(genre.equalsIgnoreCase("D"))
        {
            genre = "Drama";
        }
        else if(genre.equalsIgnoreCase("E"))
        {
            genre = "Education";
        }
        else if(genre.equalsIgnoreCase("C"))
        {
            genre = "Classic";
        }
        else if(genre.equalsIgnoreCase("F"))
        {
            genre = "Fantasy";
        }
        else
        {
            genre = "Science Fiction";
        }
        return String.format("%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n","ISBN:", super.getIsbn(),"Call Number:",super.getCallNumber(),"Available:",super.getAvailable(),"Total:",super.getTotal(),"Title:",super.getTitle(),"Author",author,"Year",year, "Genre:",genre);
    }


}
