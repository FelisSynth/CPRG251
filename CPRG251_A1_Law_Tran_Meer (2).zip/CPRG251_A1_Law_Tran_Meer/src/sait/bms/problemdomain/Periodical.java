package sait.bms.problemdomain;
import java.util.*;

/**
 * One of the 4 subclasses of the Book class
 *
 * Contains constructor for list of Periodicals, getters, setters
 * and method to display books in a readable format.
 *
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */
public class Periodical extends Book{
    
	private ArrayList<Periodical> periodicalList= new ArrayList<Periodical>();
    private String frequency;

    /**
     * default constructor for Periodical object
     */
    public Periodical() 
    {

    }

    /**
     * Book constructor with attributes as parameters
     *
     * @param isbn the book's isbn
     * @param callNumber call number for a book
     * @param available the number of books available
     * @param total the total number of books
     * @param title the title of the book
     * @param frequency frequency of the book
     */
    public Periodical(String isbn, String callNumber, int available, int total, String title, String frequency) 
    {
        super(isbn, callNumber, available, total, title);
        this.frequency = frequency;
    }


    /**
     * Method to return list of Periodical
     *
     * @return list of Periodical
     */
    public ArrayList<Periodical> getPeriodicalList() {
        return periodicalList;
    }

    /**
     * Method to write and update the Periodical list
     *
     * @param periodical list of Periodical
     */
    public void setPeriodicalList(Periodical periodical) {
        this.periodicalList.add(periodical);
    }

    /**
     * getter method for book frequency
     *
     * @return book frequency
     */
    public String getFrequency() {
        return frequency;
    }

    /**
     * setter method for book frequency
     *
     * @param frequency book frequency
     */
    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    /**
     * Method to display Periodicals
     *
     * @return formatted display of Periodical
     */
    public String toString()
    {
        if(frequency.equalsIgnoreCase("D")) 
        {
            frequency = "Daily";
        }
        else if(frequency.equalsIgnoreCase("W"))
        {
            frequency = "Weekly";
        }
        else if(frequency.equalsIgnoreCase("M"))
        {
            frequency = "Monthly";
        }
        else if(frequency.equalsIgnoreCase("B"))
        {
            frequency = "Bimonthly";
        }
        else
        {
            frequency = "Quarterly";
        }
        return String.format("%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n%-20s%s\n","ISBN:", super.getIsbn(),"Call Number:",super.getCallNumber(),"Available:",super.getAvailable(),"Total:",super.getTotal(),"Title:",super.getTitle(),"Frequency:",frequency);
    }

}