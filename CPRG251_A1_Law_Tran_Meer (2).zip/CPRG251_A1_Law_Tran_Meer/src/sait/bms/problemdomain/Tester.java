package sait.bms.problemdomain;

import java.util.*;
import java.io.*;

/**
 * The class for testing the program
 *
 * Contains the Menu options, main method which filters books into
 * their respective types, the interactions for menu option 2 and 4,
 * and file saving method
 *
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */
public class Tester 
{
		static Main main = new Main();
		static ChildrensBook mainChildrensBook = new ChildrensBook();
		static Cookbook mainCookbook = new Cookbook();
		static Paperback mainPaperback = new Paperback();
		static Periodical mainPeriodical = new Periodical();
		static Scanner userInput;

	/**
	 * Method to display menu options and interact with other methods
	 *
	 * The method prompts the user to choose an option, then start the process
	 * for the options chosen. Catches exception if user input does not match
	 * any of the options
	 */
		public static void MainMenu() 
		{
			userInput = new Scanner(System.in);
			int choice;
				System.out.printf("\n");
				System.out.println("Welcome in ABC Book Company: How May We Assist You?");
				System.out.println("1     Checkout Book");
				System.out.println("2     Find Book by Title");
				System.out.println("3     Display Books by Type");
				System.out.println("4     Produce Random Book List");
				System.out.println("5     Save & Exit");
				System.out.println("");
				System.out.print("Enter Option: ");	
				
				choice = userInput.nextInt();
				
				switch(choice)
				{
				case 1: choice = 1;
					main.checkoutBook();
					
					MainMenu();
				case 2: choice = 2;
					titleSearch();
					
					MainMenu();
				case 3:
					System.out.printf("#     Type\n1     Children's Books\n2     Cookbooks\n3     Paperback\n4     Periodicals\n\nEnter type of book: ");
			        String selection = userInput.next();
			        switch(selection.charAt(0))
			        {
			        case '1':
			            childrensBookFilter();
			            break;
			        case '2':
			            cookBookFilter();
			            break;
			        case '3':
			            paperbackFilter();
			            break;
			        case '4':
			            periodicalFilter();
			            break;
			        default:
			        System.out.print(choice + "is not an option\n\n");
			            break;
			        }
			        MainMenu();
				case 4: choice = 4;
					randomBook();
				
					MainMenu();
				case 5: choice = 5;
					System.out.print("\nThank you for stopping by,\nEnjoy your day!");
					try 
					{
						fileSave();
					} 
					
					catch(Exception FileError) 
					{
						System.out.printf("There was an error with the file: \nPlease ensure you have the correct directory \nError: FileError");	
						System.exit(0);
					}
					System.exit(0);
				}
				
			
			}

	/**
	 * The main method
	 *
	 * The method creates an ArrayList of type Book, then reads from the file
	 * and assign entries into their respective book types.
	 * Catches IOException if the file is unavailable
	 *
	 * @param args standard argument
	 * @throws IOException Input-Output Exception
	 */
	public static void main(String[] args) throws IOException
	{
		ArrayList<Book> allBookList= new ArrayList<>();
		
		File books = new File("C://books.txt");
		Scanner bookReader = new Scanner(books);
		
		
		
		String[] temp= new String [7];
		String isbn;
		String callNumber;
		int available;
		int total;
		String title;
		while(bookReader.hasNextLine())
		{
			temp = bookReader.nextLine().split(";");
		
			isbn = temp[0];
			callNumber = temp[1];
			available = Integer.parseInt(temp[2]);
			total = Integer.parseInt(temp[3]);
			title = temp[4];
						
			switch(isbn.charAt(12))
			{
			case '0':
			case '1':
				ChildrensBook childrensBook = new ChildrensBook(isbn,callNumber,available,total,title,temp[5],temp[6]);
				mainChildrensBook.setchildrensBookList(childrensBook);
				allBookList.add(childrensBook);
				
				break;
			case '2':
			case '3':
				Cookbook cookbook = new Cookbook(isbn,callNumber,available,total,title,temp[5],temp[6]);
				mainCookbook.setCookbookList(cookbook);
				allBookList.add(cookbook);
				
				break;
			case '4':
			case '5':
			case '6':
			case '7':
				Paperback paperback = new Paperback(isbn,callNumber,available,total,title,temp[5],temp[6],temp[7]);
				mainPaperback.setPaperbackList(paperback);
				allBookList.add(paperback);
				
				break;
			case '8':
			case '9':
				Periodical periodical = new Periodical(isbn,callNumber,available,total,title,temp[5]);
				mainPeriodical.setPeriodicalList(periodical);
				allBookList.add(periodical);
				
				break;
			default:
				System.out.print("error");
				userInput.close();
				break;
			}
		}
		main.setAllBookList(allBookList);
		MainMenu();
	}

	/**
	 * Method to process the 2nd Menu option
	 *
	 * The method takes the user input and checks if any book titles contain the search term.
	 * If there is an entry found, the book is then displayed according to its respective format.
	 * Displays "No Book available." if no entries are found.
	 */
	public static void titleSearch()
	{
		userInput = new Scanner(System.in);
		System.out.print("Enter Title to search for: ");
		String searchTitle = userInput.nextLine();
		
		System.out.print("\nMatching books: \n");
		
		for(int count = 0; count < main.getAllBookList().size(); count ++)
		{
		if(!searchTitle.isEmpty())
		{
			if(main.getAllBookList().get(count).getTitle().toLowerCase().contains(searchTitle.toLowerCase()))
			{
				switch(main.getAllBookList().get(count).getIsbn().charAt(12))
				{
				case '0':
				case '1':
					for(int count1 = 0; count1 < mainChildrensBook.getChildrensBookList().size(); count1++)
					{		
						if(mainChildrensBook.getChildrensBookList().get(count1).getIsbn().equalsIgnoreCase(main.getAllBookList().get(count).getIsbn()))
						{
						System.out.println(mainChildrensBook.getChildrensBookList().get(count1).toString());
						}
					}
					
					break;
				case '2':
				case '3':
					for(int count1 = 0; count1 < mainCookbook.getCookbookList().size(); count1++)
					{		
						if(mainCookbook.getCookbookList().get(count1).getIsbn().equalsIgnoreCase(main.getAllBookList().get(count).getIsbn()))
						{
						System.out.println(mainCookbook.getCookbookList().get(count1).toString());
						}
					}
					
					break;
				case '4':
				case '5':
				case '6':
				case '7':
					for(int count1 = 0; count1 < mainPaperback.getPaperbackList().size(); count1++)
					{		
						if(mainPaperback.getPaperbackList().get(count1).getIsbn().equalsIgnoreCase(main.getAllBookList().get(count).getIsbn()))
						{
						System.out.println(mainPaperback.getPaperbackList().get(count1).toString());
						}
					}
					break;
				case '8':
				case '9':
					for(int count1 = 0; count1 < mainPeriodical.getPeriodicalList().size(); count1++)
					{		
						if(mainPeriodical.getPeriodicalList().get(count1).getIsbn().equalsIgnoreCase(main.getAllBookList().get(count).getIsbn()))
						{
						System.out.println(mainPeriodical.getPeriodicalList().get(count1).toString());
						}
					}
					break;
				default:
					System.out.print("error");
					break;
				}
				
			}
		}
		
		else
		{
			System.out.print("\nNo Book available.");
			break;
		}
		
		}
	}

	/**
	 * Method to filter the type of Children's books
	 *
	 * The method takes the user input, then search for books of that type
	 * and displays it in a readable format
	 */
	public static void childrensBookFilter()
	{
		userInput = new Scanner(System.in);
		System.out.print("Enter a format (P for Picture Book, E for Early Readers, or C for Chapter Books): ");
		char choice = (userInput.next().toUpperCase().charAt(0));
		switch(choice)
		{
		case'P':
			for(int x = 0; x < mainChildrensBook.getChildrensBookList().size(); x++)
			{
				if(mainChildrensBook.getChildrensBookList().get(x).getFormat().charAt(0) == 'P') 
				{
					System.out.print(mainChildrensBook.getChildrensBookList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case'E':
			for(int x = 0; x < mainChildrensBook.getChildrensBookList().size(); x++)
			{
				if(mainChildrensBook.getChildrensBookList().get(x).getFormat().charAt(0) == 'E') 
				{
					System.out.print(mainChildrensBook.getChildrensBookList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case'C':
			for(int x = 0; x < mainChildrensBook.getChildrensBookList().size(); x++)
			{
				if(mainChildrensBook.getChildrensBookList().get(x).getFormat().charAt(0) == 'C') 
				{
					System.out.print(mainChildrensBook.getChildrensBookList().get(x).toString());
					System.out.println();
				}
			}
			break;
		default:
			System.out.print("not a valid input\n");
			break;
			
		}
	}

	/**
	 * Method to filter the type of Cookbooks
	 *
	 * The method takes the user input, then search for books of that diet
	 * and displays it in a readable format
	 */
	public static void cookBookFilter()
	{
		userInput = new Scanner(System.in);
		System.out.print("Enter a diet (D for Diabetic, V for Vegetarian, G for Gluten-free, I for International, or N for None): ");
		char choice = (userInput.next().toUpperCase().charAt(0));
		switch(choice)
		{
		case'D':
			for(int x = 0; x < mainCookbook.getCookbookList().size(); x++)
			{
				if(mainCookbook.getCookbookList().get(x).getDiet().charAt(0) == 'D') 
				{
					System.out.print(mainCookbook.getCookbookList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case'V':
			for(int x = 0; x < mainCookbook.getCookbookList().size(); x++)
			{
				if(mainCookbook.getCookbookList().get(x).getDiet().charAt(0) == 'V') 
				{
					System.out.print(mainCookbook.getCookbookList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case'G':
			for(int x = 0; x < mainCookbook.getCookbookList().size(); x++)
			{
				if(mainCookbook.getCookbookList().get(x).getDiet().charAt(0) == 'G') 
				{
					System.out.print(mainCookbook.getCookbookList().get(x).toString());
					System.out.println();
				}
			}
		case 'I':
			for(int x = 0; x < mainCookbook.getCookbookList().size(); x++)
			{
				if(mainCookbook.getCookbookList().get(x).getDiet().charAt(0) == 'I') 
				{
					System.out.print(mainCookbook.getCookbookList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case 'N':
			for(int x = 0; x < mainCookbook.getCookbookList().size(); x++)
			{
				if(mainCookbook.getCookbookList().get(x).getDiet().charAt(0) == 'N') 
				{
					System.out.print(mainCookbook.getCookbookList().get(x).toString());
					System.out.println();
				}
			}
			break;
		default:
			System.out.print("not a valid input\n");
			break;
			
		}
	}

	/**
	 * Method to filter the type of Paperbacks
	 *
	 * The method takes the user input, then search for books of that genre
	 * and displays it in a readable format
	 */
	public static void paperbackFilter()
	{
		userInput = new Scanner(System.in);
		System.out.print("Enter a genre (A for Adventure, D for Drama, E for Education, C for Classic, F for Fantasy, or S for Science Fiction): ");
		char choice = (userInput.next().toUpperCase().charAt(0));
		switch(choice)
		{
		case'A':
			for(int x = 0; x < mainPaperback.getPaperbackList().size(); x++)
			{
				if(mainPaperback.getPaperbackList().get(x).getGenre().charAt(0) == 'A') 
				{
					System.out.print(mainPaperback.getPaperbackList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case'D':
			for(int x = 0; x < mainPaperback.getPaperbackList().size(); x++)
			{
				if(mainPaperback.getPaperbackList().get(x).getGenre().charAt(0) == 'D') 
				{
					System.out.print(mainPaperback.getPaperbackList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case'E':
			for(int x = 0; x < mainPaperback.getPaperbackList().size(); x++)
			{
				if(mainPaperback.getPaperbackList().get(x).getGenre().charAt(0) == 'E') 
				{
					System.out.print(mainPaperback.getPaperbackList().get(x).toString());
					System.out.println();
				}
			}
		case 'C':
			for(int x = 0; x < mainPaperback.getPaperbackList().size(); x++)
			{
				if(mainPaperback.getPaperbackList().get(x).getGenre().charAt(0) == 'C') 
				{
					System.out.print(mainPaperback.getPaperbackList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case 'F':
			for(int x = 0; x < mainPaperback.getPaperbackList().size(); x++)
			{
				if(mainPaperback.getPaperbackList().get(x).getGenre().charAt(0) == 'F') 
				{
					System.out.print(mainPaperback.getPaperbackList().get(x).toString());
					System.out.println();
				}
			}
			break;
		case 'S':
			for(int x = 0; x < mainPaperback.getPaperbackList().size(); x++)
			{
				if(mainPaperback.getPaperbackList().get(x).getGenre().charAt(0) == 'S') 
				{
					System.out.print(mainPaperback.getPaperbackList().get(x).toString());
					System.out.println();
				}
			}
		default:
			System.out.print("not a valid input\n");
			break;
			
		}
	}

	/**
	 * Method to filter the type of Periodicals
	 *
	 * The method takes the user input, then search for books of that frequency
	 * and displays it in a readable format
	 */
	public static void periodicalFilter()
    {
        userInput = new Scanner(System.in);
        System.out.print("Enter a frequecny (D for Daily, W for Weekly, M for Monthly, B for Bimonthly, or Q for Quarterly): ");
        char choice = (userInput.next().toUpperCase().charAt(0));
        System.out.print("\nMatching book:");
        switch(choice)
        {
        case'D':
            for(int x = 0; x < mainPeriodical.getPeriodicalList().size(); x++)
            {
                if(mainPeriodical.getPeriodicalList().get(x).getFrequency().charAt(0) == 'D') 
                {
                    System.out.print(mainPeriodical.getPeriodicalList().get(x).toString());
                    System.out.println();
                }
            }
            break;
        case'W':
            for(int x = 0; x < mainPeriodical.getPeriodicalList().size(); x++)
            {
                if(mainPeriodical.getPeriodicalList().get(x).getFrequency().charAt(0) == 'W') 
                {
                    System.out.print(mainPeriodical.getPeriodicalList().get(x).toString());
                    System.out.println();
                }
            }
            break;
        case'M':
            for(int x = 0; x < mainPeriodical.getPeriodicalList().size(); x++)
            {
                if(mainPeriodical.getPeriodicalList().get(x).getFrequency().charAt(0) == 'M') 
                {
                    System.out.print(mainPeriodical.getPeriodicalList().get(x).toString());
                    System.out.println();
                }
            }
        case 'B':
            for(int x = 0; x < mainPeriodical.getPeriodicalList().size(); x++)
            {
                if(mainPeriodical.getPeriodicalList().get(x).getFrequency().charAt(0) == 'B') 
                {
                    System.out.print(mainPeriodical.getPeriodicalList().get(x).toString());
                    System.out.println();
                }
            }
            break;
        case 'Q':
            for(int x = 0; x < mainPeriodical.getPeriodicalList().size(); x++)
            {
                if(mainPeriodical.getPeriodicalList().get(x).getFrequency().charAt(0) == 'Q') 
                {
                    System.out.print(mainPeriodical.getPeriodicalList().get(x).toString());
                    System.out.println();
                }
            }
            break;
        default:
            System.out.print("not a valid input\n");
            break;
            
        }
    }

	/**
	 * Method to process the 4th Menu option
	 *
	 * The method takes the input, and generate a loop according to
	 * how many books the user wants to be displayed.
	 * The program then picks randomly a subclass, and picks a random book from that type
	 * then displays it in a readable format.
	 * The process is repeated until the loop terminates
	 */
	public static void randomBook()
	{
		{
			userInput = new Scanner(System.in);
			System.out.print("Enter number of books: ");
			int count = userInput.nextInt();
			System.out.println("\nRandom Books:");
			
			for(count = count; count > 0; count --)
			{
			
	        int randomCatagory = (int)(Math.random() * (3));
	        switch(randomCatagory)
	        {
	        case 0:
	            int randomChildrensBookIndex = (int)(Math.random() * (mainChildrensBook.getChildrensBookList().size() - 1));
	            System.out.print(mainChildrensBook.getChildrensBookList().get(randomChildrensBookIndex).toString());
	            System.out.println();
	            break;
	        case 1:
	            int randomCookBookIndex = (int)(Math.random() * (mainCookbook.getCookbookList().size() - 1));
	            System.out.print(mainCookbook.getCookbookList().get(randomCookBookIndex).toString());
	            System.out.println();
	            break;
	        case 2:
	            int randomPaperbackIndex = (int)(Math.random() * (mainPaperback.getPaperbackList().size() - 1));
	            System.out.print(mainPaperback.getPaperbackList().get(randomPaperbackIndex).toString());
	            System.out.println();
	            break;
	        case 3:
	            int randomPeriodicalIndex = (int)(Math.random() * (mainPeriodical.getPeriodicalList().size() - 1));
	            System.out.print(mainPeriodical.getPeriodicalList().get(randomPeriodicalIndex).toString());
	            System.out.println();
	            break;
	        }
	        }
	    }
	}

	/**
	 * Method to save changes to the original document
	 *
	 * The method loops through the original document, matches the book entry with
	 * the entry in the ArrayList of its subtype (through ISBN), then overwrite the
	 * original document with the entry in the ArrayList to update any changes.
	 * The book objects are converted into Strings with the correct format before
	 * overwriting the original document
	 *
	 * @throws IOException Input-Output Exception
	 */
	public static void fileSave() throws IOException
    {
        FileWriter printWriter = new FileWriter("c:\\books.txt");
        for(int x = 0; x < main.getAllBookList().size(); x++)
        {
            char bookIsbn = main.getAllBookList().get(x).getIsbn().charAt(12);
            if(bookIsbn == '0' || bookIsbn == '1')
            {
                for(int y = 0; y < mainChildrensBook.getChildrensBookList().size(); y++)
                {
                    if(mainChildrensBook.getChildrensBookList().get(y).getIsbn().equalsIgnoreCase(main.getAllBookList().get(x).getIsbn()))
                    {
                        String temp =String.format("%s;%s;%d;%d;%s;%s;%s\n",mainChildrensBook.getChildrensBookList().get(y).getIsbn(),mainChildrensBook.getChildrensBookList().get(y).getCallNumber(),mainChildrensBook.getChildrensBookList().get(y).getAvailable(),mainChildrensBook.getChildrensBookList().get(y).getTotal(),mainChildrensBook.getChildrensBookList().get(y).getTitle(),mainChildrensBook.getChildrensBookList().get(y).getAuthors(),mainChildrensBook.getChildrensBookList().get(y).getFormat());
                        printWriter.write(temp);
                        break;
                    }

                }
            }
            else if(bookIsbn == '2' || bookIsbn == '3')
            {
                for(int y = 0; y < mainCookbook.getCookbookList().size(); y++)
                {
                    if(mainCookbook.getCookbookList().get(y).getIsbn().equalsIgnoreCase(main.getAllBookList().get(x).getIsbn()))
                    {
                    	String temp =String.format("%s;%s;%d;%d;%s;%s;%s\n",mainCookbook.getCookbookList().get(y).getIsbn(),mainCookbook.getCookbookList().get(y).getCallNumber(),mainCookbook.getCookbookList().get(y).getAvailable(),mainCookbook.getCookbookList().get(y).getTotal(),mainCookbook.getCookbookList().get(y).getTitle(),mainCookbook.getCookbookList().get(y).getPublisher(),mainCookbook.getCookbookList().get(y).getDiet());
                    	printWriter.write(temp);
                        break;
                    }
                }
            }
            else if(bookIsbn >= '4' && bookIsbn <= '7')
            {
                for(int y = 0; y < mainPaperback.getPaperbackList().size(); y++)
                {
                    if(mainPaperback.getPaperbackList().get(y).getIsbn().equalsIgnoreCase(main.getAllBookList().get(x).getIsbn()))
                    {
                    	String temp =String.format("%s;%s;%d;%d;%s;%s;%s;%s\n",mainPaperback.getPaperbackList().get(y).getIsbn(),mainPaperback.getPaperbackList().get(y).getCallNumber(),mainPaperback.getPaperbackList().get(y).getAvailable(),mainPaperback.getPaperbackList().get(y).getTotal(),mainPaperback.getPaperbackList().get(y).getTitle(),mainPaperback.getPaperbackList().get(y).getAuthor(),mainPaperback.getPaperbackList().get(y).getYear(),mainPaperback.getPaperbackList().get(y).getGenre());
                    	printWriter.write(temp);
                        break;
                    }
                }
            }
            else if(bookIsbn == '8' || bookIsbn == '9')
            {
                for(int y = 0; y < mainPeriodical.getPeriodicalList().size(); y++)
                {
                    if(mainPeriodical.getPeriodicalList().get(y).getIsbn().equalsIgnoreCase(main.getAllBookList().get(x).getIsbn()))
                    {
                    	String temp =String.format("%s;%s;%d;%d;%s;%s\n",mainPeriodical.getPeriodicalList().get(y).getIsbn(),mainPeriodical.getPeriodicalList().get(y).getCallNumber(),mainPeriodical.getPeriodicalList().get(y).getAvailable(),mainPeriodical.getPeriodicalList().get(y).getTotal(),mainPeriodical.getPeriodicalList().get(y).getTitle(),mainPeriodical.getPeriodicalList().get(y).getFrequency());
                    	printWriter.write(temp);
                        break;
                    }
                }
            }
        }
    printWriter.close();
    }
}
