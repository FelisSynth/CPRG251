package sait.sll.utility;

import java.io.Serializable;

public class SLL implements LinkedListADT, Serializable
{
    private Node head = null;
    private Node tail = null;
    private int size = 0;

    
    public SLL() 
    {
        
    }


    @Override
    public boolean isEmpty() {
        return (size == 0);
        
    }

    @Override
    public void clear() {
    	this.head = null;
    	this.tail = head;
    	this.size = 0;
    }

    @Override
    public void append(Object data) {
        if(this.isEmpty()) {
            head = new Node(data,null,null);
            tail = head;
        }        
        else
        {
            Node inputNode = new Node(data,null,tail);
            tail.setNext(inputNode);
            tail = inputNode;
        }
        size++;
    }

    @Override
    public void prepend(Object data) {
        if(this.isEmpty()) {
            head = new Node(data,null,null);
            tail = head;
        }        
        else
        {
            Node inputNode = new Node(data,head,null);
            inputNode.setNext(head);
            head = inputNode;
        }
        size++;
    }

    @Override
    public void insert(Object data, int index) throws IndexOutOfBoundsException {
    	int count = 0;
    	Node insertNode = new Node(data,null,null);
    	Node current = head;
    	while(count < this.size)
    	{
    		if(count == index-1)
    		{
    		insertNode.setNext(current.getNext());
    		current.setNext(insertNode);
    		size++;
    		}
    		current = current.getNext();
    		count++;
    	}
    	
    	
    }

    @Override
    public void replace(Object data, int index) throws IndexOutOfBoundsException {
        delete(index);
        insert(data,index);
    }

    @Override
    public int size() {
    	return size;
    }

    @Override
    public void delete(int index) throws IndexOutOfBoundsException {
    	int count = 0;
    	Node current = head;
    	while(count < this.size)
    	{
    		if(count == index-1)
    		{
    		current.setNext(current.getNext().getNext());
    		size--;
    		}
    		current = current.getNext();
    		count++;
    	}
    }

    @Override
    public Object retrieve(int index) throws IndexOutOfBoundsException {
    	Node current = head;
    	int count = 0;
    	while(current != null)
    	{
    		if(count == index)
    		{
    			return current.getData();
    		}
    		current = current.getNext();
    		count++;
    	}
    	return null;
    }

    @Override
    public int indexOf(Object data) {
    	Node current = head;
    	int count = 0;
    	while(current != null)
    	{
    		if(current.getData() == data)
    		{
    			return count;
    		}
    		current = current.getNext();
    		count++;
    	}
    	return -1;
    }

    @Override
    public boolean contains(Object data) {
    	Node current = head;
    	int count = 0;
    	while(current != null)
    	{
    		if(current.getData() == data)
    		{
    			return true;
    		}
    		current = current.getNext();
    		count++;
    	}
    	return false;
    }
    
}