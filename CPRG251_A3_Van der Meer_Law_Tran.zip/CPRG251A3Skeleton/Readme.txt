CPRG251 - Assignment 3 - Linked List - Unit Testing - Serialization

The program creates a linked list which implements the LinkedListADT Interface
The program features testing cases for the linked list's functions as well as serializability

Date: 10-April-2022
Author: Dylano Van der Meer, Joshua Law, Trung Hieu Tran
How to run: Open the program through Eclipse IDE and run the codes in the test package