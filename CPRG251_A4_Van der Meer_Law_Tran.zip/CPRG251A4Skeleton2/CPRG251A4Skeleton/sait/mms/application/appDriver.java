/**
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 * @version 21/4/2022
 *
 * The AppDriver for the program
 */

package mms.application;
import java.sql.SQLException;

import mms.managers.MovieManagmentSystem;

/**
 * The appDriver class
 */
public class appDriver {
	/**
	 * Main method
	 * @param args
	 * @throws SQLException
	 */
	public static void main(String [] args) throws SQLException
	{
		/**
		 * Create new instance of Movie Management System
		 * Displays the Menu
		 */
		MovieManagmentSystem Start = new MovieManagmentSystem();
		Start.displayMenu();
	}
}
