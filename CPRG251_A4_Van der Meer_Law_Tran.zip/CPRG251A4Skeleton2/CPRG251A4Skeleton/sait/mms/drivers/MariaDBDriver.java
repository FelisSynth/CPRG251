/**
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 * @version 21/4/2022
 *
 * The Maria Database Driver for the program
 */
package mms.drivers;

import java.sql.*;

import mms.contracts.DatabaseDriver;

/**
 * The MariaDBDriver class
 */
public class MariaDBDriver implements DatabaseDriver{
	private Connection connection;
	
	
	@Override
	public void connect() throws SQLException {
		this.connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/cprg251", "cprg251","password");
	}

	@Override
	public ResultSet get(String query) throws SQLException {
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(query);
		return resultSet;
	}

	@Override
	public int update(String query) throws SQLException {
		Statement statement = connection.createStatement();
		int rows = statement.executeUpdate(query);
		return rows;
	}

	@Override
	public void disconnect() throws SQLException {
		this.connection.commit();
		this.connection.close();
	}

}
