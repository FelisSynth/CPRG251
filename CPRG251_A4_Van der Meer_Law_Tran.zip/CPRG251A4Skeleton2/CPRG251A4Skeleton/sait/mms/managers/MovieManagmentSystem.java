/**
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 * @version 21/4/2022
 *
 * The Movie Management System of the program
 */
package mms.managers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import mms.drivers.MariaDBDriver;
import mms.problemdomain.Movie;

/**
 * The MovieManagementSystem class
 */
public class MovieManagmentSystem {
	private static MariaDBDriver driver = new MariaDBDriver();
	private Scanner scanner = new Scanner(System.in);
	/**
	 * Constructor for movie management system instance
	 * @throws SQLException
	 */
	public MovieManagmentSystem() throws SQLException
	{
			driver.connect();
	}
	/**
	 * Method to display the Menu
	 * @throws SQLException
	 */
	public void displayMenu() throws SQLException
	{
		System.out.print("Jim's Movie Manager\n");
		System.out.printf("%-8d%s\n", 1, "Add New Movie");
		System.out.printf("%-8d%s\n", 2, "Print movies release in year");
		System.out.printf("%-8d%s\n", 3, "Print random list of movies");
		System.out.printf("%-8d%s\n", 4, "Delete a movie");
		System.out.printf("%-8d%s\n", 5, "Exit");
		System.out.print("\nEnter an option: ");
		char choice = scanner.next().charAt(0);
		
		/**
		 * Menu options
		 */
		switch(choice)
		{
		case '1':
			addMovie();
			displayMenu();
		case '2':
			printMoviesInYear();
			displayMenu();
		case '3':
			printRandomMovies();
			displayMenu();
		case '4':
			deleteMovie();
			displayMenu();
		case '5':
			driver.disconnect();
			System.out.print("\n\nGoodbye!");
			System.exit(0);
		default:
			break;
		
		}
	}
	
	/**
	 * Method to add a movie to the database
	 * User is promted to enter the movie Title, Duration and Year
	 * Wrong format exception for duration and year will be caught and user is sent to the menu
	 * 
	 * If a change is successfully made (row > 0), a message will appear saying movie is added
	 * @throws SQLException
	 */
	public void addMovie() throws SQLException, InputMismatchException {
		scanner.nextLine();
		String title = "";
		int duration = 0;
		int year = 0;
		try	{
		System.out.print("\nEnter movie title: ");
		title = scanner.nextLine();
		System.out.print("Enter duration: ");
		duration = scanner.nextInt();
		System.out.print("Enter year: ");
		year = scanner.nextInt();
		
		String query = "INSERT INTO MOVIES(duration, title, year) "
				+ "VALUES (" + duration + ",  '" + title + "',  '" + year + "');";
		
		int rows = driver.update(query);
		
		if(rows > 0) {
		System.out.print("\nAdded movie to database.\n\n");
		}
		
		else {
		System.out.print("An error occurred, movie not added to the database");
		}
		} 
		catch (InputMismatchException ex) {
			System.out.println("\nWrong Input Format\n");
			scanner.next();
		} 
		catch (SQLException ex)
		{
			System.out.println("\nSQL Syntax error\nCheck Inputs\n");

		}
		
	}
	
	/**
	 * Method to delete a movie
	 * User is prompted to enter the ID of the movie to delete
	 * Wrong format exception for movie ID will be caught and user is sent to the menu
	 * 
	 * If a change is successfully made (row > 0), a message will appear saying the movie is deleted
	 * @throws SQLException
	 */
	public void deleteMovie() throws SQLException, InputMismatchException
	{
		System.out.print("\nEnter a movie ID that you want to delete: ");
		int id = 0;
		try {
			id = scanner.nextInt();
			String query = "DELETE FROM MOVIES "
					 + "WHERE ID  = '" + id + "';";
		int rows = driver.update(query);
		if(rows > 0)
		{
			System.out.print("\nMovie " + id + " is deleted\n\n");
		}
		else
		{
		System.out.print("\nAn error occurred, movie does not exist in the database\n\n");
		}
		} 
		catch (InputMismatchException ex) {
			System.out.println("\nWrong Input Format\n");
			scanner.next();
		}
	}
	
	/**
	 * Method to print list of movies in a specific year
	 * User is prompted to enter the year they want
	 * Wrong format exception will be caught and user is prompted again for the year
	 * 
	 * If no exceptions occur, a list is displayed containing movies made in the inputted year
	 * @throws SQLException
	 */
	public void printMoviesInYear() throws SQLException, InputMismatchException {
		System.out.print("\nEnter in year: ");
		int year = 0;
		try {
			year = scanner.nextInt();
			
			String query = "SELECT duration,year,title from MOVIES "
				     + "WHERE year = '" + year + "';";
		
			ResultSet rSet = driver.get(query);
		
			int duration = 0;
			System.out.print("\n\nMovie List");
			System.out.print(String.format("\n%-16s%-8s%-50s","Duration","Year", "Title"));
			while(rSet.next())
			{
				Movie movie = new Movie(rSet.getInt("duration"),rSet.getInt("year"), rSet.getString("title"));
				System.out.print(movie.toString());
				duration += movie.getDuration();
			}
			System.out.print("\n\nTotal Duration: " + duration + " minutes\n\n");
			
		} catch (InputMismatchException ex) {
			System.out.println("\nWrong Input Format\n");
			scanner.next();
		}
		
		
		
	}
	
	/**
	 * Method to print a random list of movies
	 * User is promted to enter a number of random movies
	 * Wrong format exception will be caught and the user is prompted for the number again
	 * 
	 * If no excetions occur, a list of random movies will be displayed, the length of which will be the inputted number
	 * @throws SQLException
	 */
	public void printRandomMovies() throws SQLException, InputMismatchException {
		System.out.print("\nEnter number of movies: ");
		int movieCount = 0;
		try {
			movieCount = scanner.nextInt();
			String query = "SELECT * from MOVIES "
					 + "ORDER BY RAND();";
		
		ResultSet rSet = driver.get(query);
		int duration = 0;
		System.out.print("\nMovie List");
		System.out.print(String.format("\n%-16s%-8s%-50s","Duration","Year", "Title"));
		
		for(int x = 0; x < movieCount; x++) {
			if(rSet.next()) {
				Movie movie = new Movie(rSet.getInt("duration"),rSet.getInt("year"), rSet.getString("title"));
				System.out.print(movie.toString());
				duration += movie.getDuration();
			}
			
			else {
				System.out.print("\n\nYou have exceeded the number of movies!\nNo more movies can be loaded");
				break;
			}
		}
		System.out.print("\n\nTotal duration: " + duration + " minutes\n\n\n");
		} catch (InputMismatchException ex) {
			System.out.println("\nWrong Input Format\n");
			scanner.next();
		}
		
	}
	
}
