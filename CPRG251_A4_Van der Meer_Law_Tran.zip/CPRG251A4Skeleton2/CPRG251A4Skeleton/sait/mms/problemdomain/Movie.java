/**
 * @author Dylano Van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 * @version 21/4/2022
 *
 * The AppDriver for the program
 */
package mms.problemdomain;

/**
 * The movie class
 */
public class Movie {
	private int duration;
	private String title;
	private int year;

	/**
	 * Constructor for movie object
	 * @param duration
	 * @param year
	 * @param title
	 */
	public Movie(int duration,  int year, String title) {
		this.duration = duration;
		this.title = title;
		this.year = year;
	}

	/**
	 * Getter for movie duration
	 * @return duration of movie
	 */
	public int getDuration() {
		return duration;
	}

	/**
	 * Setter for movie duration
	 * @param duration
	 */
	public void setDuration(int duration) {
		this.duration = duration;
	}

	/**
	 * Getter for movie title
	 * @return movie title
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * Setter for movie title
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * getter for movie year
	 * @return movie year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * setter for movie year
	 * @param year
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * toString method to display movie
	 * @return formatted string for movie display
	 */
	public String toString() {
		return String.format("\n%-16d%-8s%-50s",duration,year,title);
	}
	
	
}
