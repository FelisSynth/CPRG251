public class test {

	public static void main(String[] args) {
		System.out.println(String.format("%-10s%-5s%-30s","Duration","Year", "Title"));
		System.out.println(String.format("%-10d%-5s%-30s",114,"2002", "Tester"));
	}

}
