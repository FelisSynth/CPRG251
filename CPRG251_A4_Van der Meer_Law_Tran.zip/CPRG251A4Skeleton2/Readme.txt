CPRG 250 - Assignment 4

The program is a database manager for Jim's Movie House.
The program is a command line application that features adding movies, deleting movies into a database,
displaying a list of movies in a specific year and displaying a list of random movies.

Date: 22nd April 2022
Author: Dylano Van der Meer, Joshua Law, Trung Hieu Tran

How to run:
Open Command Prompt
Locate and go into the directory containing the .jar file
Run the jar file with Command Prompt (<java -jar "Jim'sMovieManager.jar")