/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

/**
 * Custom Exception class
 * 
 * Empty Input Exception is called when input is empty or null
 */

package sait.frms.exception;
public class EmptyInputException extends Exception {
	/**
	 * Constructor for the exception
	 * @param message message for the console
	 */
    public EmptyInputException(String message) {
        super(message);
    }
}