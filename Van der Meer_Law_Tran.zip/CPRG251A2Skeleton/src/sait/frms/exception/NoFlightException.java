/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

/**
 * Custom Exception class
 * 
 * No Flight Exception is called when no flight is selected
 */
package sait.frms.exception;

public class NoFlightException extends Exception{
	/**
	 * Constructor for the exception
	 * @param message message for the console
	 */
	public NoFlightException(String message) {
		super(message);
	}
}
