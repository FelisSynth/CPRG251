/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

/**
 * Custom Exception class
 * 
 * Seats Full Exception is called when input is empty or null
 */
package sait.frms.exception;
public class SeatsFullException extends Exception {
	/**
	 * Constructor for the exception
	 * @param message message for the console
	 */
	public SeatsFullException(String message) {
		super(message);
	}
}
