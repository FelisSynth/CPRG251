/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

/**
 * Custom Exception class
 * 
 * Wrong Format Exception is called when file entry has wrong format
 */
package sait.frms.exception;
public class WrongFormatException extends Exception {
	/**
	 * Constructor for the exception
	 * @param message message for the console
	 */
	public WrongFormatException(String message) {
		super(message);
	}
}
