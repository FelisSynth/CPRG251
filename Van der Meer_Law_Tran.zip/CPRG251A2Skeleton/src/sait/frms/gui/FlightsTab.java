/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

package sait.frms.gui;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.*;

import sait.frms.exception.EmptyInputException;
import sait.frms.exception.NoFlightException;
import sait.frms.exception.SeatsFullException;
import sait.frms.manager.FlightManager;
import sait.frms.manager.ReservationManager;
import sait.frms.problemdomain.Flight;

/**
 * Holds the components for the flights tab.
 * 
 */
public class FlightsTab extends TabBase implements ActionListener
{
	/**
	 * Instance of flight manager.
	 */
	private FlightManager flightManager;
	
	/**
	 * Instance of reservation manager.
	 */
	private ReservationManager reservationManager;
	
	/**
	 * List of flights.
	 */
	private JList<Flight> flightsList;
	
	private DefaultListModel<Flight> flightsModel;
	
	/**
	 * Creates the components for flights tab.
	 */
	
	/**
	* Fields and buttons for Find flights component
	*/
	private JButton findFlights;
	private JComboBox<String> tFrom;
	private JComboBox<String> tTo;
	private JComboBox<String> tDate;
	  
	/**
	* Fields and buttons for Make reservation component
	*/
	private JButton reserve;
	private JTextField tFlight;
	private JTextField tAirline;
	private JTextField tDay;
	private JTextField tTime;
	private JTextField tCost;
	private JTextField tName;
	private JTextField tCitizenship;
	  
	/**
	 * Creates the components for flights tab.
	 * 
	 * @param flightManager Instance of FlightManager.
	 * @param reservationManager Instance of ReservationManager
	 * @throws FileNotFoundException 
	 */
	public FlightsTab(FlightManager flightManager, ReservationManager reservationManager) throws FileNotFoundException {
		this.flightManager = flightManager;
		this.reservationManager = reservationManager;
		
		panel.setLayout(new BorderLayout());
		
		JPanel northPanel = createNorthPanel();
		panel.add(northPanel, BorderLayout.NORTH);
		
		JPanel centerPanel = createCenterPanel();
		panel.add(centerPanel, BorderLayout.CENTER);
		
		JPanel eastPanel = createEastPanel();
		panel.add(eastPanel, BorderLayout.EAST);
		
		JPanel southPanel = createSouthPanel();
		panel.add(southPanel, BorderLayout.SOUTH);	  
		  
	}
	
	/**
	 * Creates the north panel.
	 * @return JPanel that goes in north.
	 */
	private JPanel createNorthPanel() 
	{
		JPanel panel = new JPanel();
		
		JLabel title = new JLabel("Flights", SwingConstants.CENTER);
		title.setFont(new Font("serif", Font.PLAIN, 29));
		panel.add(title);
		
		return panel;
	}
	
	/**
	 * Creates the center panel.
	 * @return JPanel that goes in center.
	 */
	private JPanel createCenterPanel() 
	{
		JPanel panel = new JPanel();
		
		panel.setLayout(new BorderLayout());
		
		flightsModel = new DefaultListModel<>();
		flightsList = new JList<Flight>(flightsModel);
		
		// User can only select one item at a time.
		flightsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		// Wrap JList in JScrollPane so it is scrollable.
		JScrollPane scrollPane = new JScrollPane(this.flightsList);
		
		flightsList.addListSelectionListener(new ListSelectionListener() {
			
			public void valueChanged(ListSelectionEvent e) {
				if(e.getSource() instanceof JList && flightsList.getSelectedValue() != null)
				{
					Flight selectedFlight =  flightsList.getSelectedValue();
					tFlight.setText(selectedFlight.getCode());
					tAirline.setText(selectedFlight.getAirlineName());
					tDay.setText(selectedFlight.getWeekday());
					tTime.setText(selectedFlight.getTime());
					tCost.setText("" + selectedFlight.getCostPerSeat());
				}
				
			}
		});		
		panel.add(scrollPane);
		
		return panel;
	}
	/**
	 * Creates the east panel.
	 * @return JPanel that goes in east.
	 */
	private JPanel createEastPanel() {
		JPanel panel = new JPanel();
		  
		panel.setLayout(new BorderLayout(10,10));
		  
		// Title for the component
		JLabel title = new JLabel("Reserve", SwingConstants.CENTER);
		title.setFont(new Font("serif", Font.PLAIN, 25));
		panel.add(title, BorderLayout.NORTH);
		  
		JPanel GridLayout = new JPanel();
		GridLayout.setLayout(new GridLayout(7,2));
		  
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new FlowLayout());
		centerPanel.add(GridLayout);
		  
		// Fields and their label in Make reservation component
		// ---------
		JLabel lFlight = new JLabel("Flight: ", SwingConstants.RIGHT);
		GridLayout.add(lFlight);
		tFlight = new JTextField(10);
		tFlight.setEditable(false);
		GridLayout.add(tFlight);
		  
		JLabel lAirline = new JLabel("Airline: ",SwingConstants.RIGHT);
		GridLayout.add(lAirline);
		tAirline = new JTextField(10);
		tAirline.setEditable(false);
		GridLayout.add(tAirline);
		  
		JLabel lDay = new JLabel("Day: ",SwingConstants.RIGHT);
		tDay = new JTextField(10);
		tDay.setEditable(false);
		GridLayout.add(lDay);
		GridLayout.add(tDay);
		  
		JLabel lTime = new JLabel("Time: ",SwingConstants.RIGHT);
		tTime = new JTextField(10);
		tTime.setEditable(false);
		GridLayout.add(lTime);
		GridLayout.add(tTime);
		  
		JLabel lCost = new JLabel("Cost: ",SwingConstants.RIGHT);
		tCost = new JTextField(10);
		tCost.setEditable(false);
		GridLayout.add(lCost);
		GridLayout.add(tCost);
		  
		JLabel lName = new JLabel("Name: ",SwingConstants.RIGHT);
		tName = new JTextField(10);
		GridLayout.add(lName);
		GridLayout.add(tName);
		  
		JLabel lCitizenship = new JLabel("Citizenship: ",SwingConstants.RIGHT);
		tCitizenship = new JTextField(10);
		GridLayout.add(lCitizenship);
		GridLayout.add(tCitizenship);
		  
		panel.add(centerPanel, BorderLayout.CENTER);
		  
		// Reservation button
		reserve = new JButton("Reserve");
		panel.add(reserve, BorderLayout.SOUTH);
		reserve.addActionListener(this);
		  
		return panel;
		}
	/**
	 * Creates the south panel.
	 * @return JPanel that goes in south.
	 */
	private JPanel createSouthPanel() throws FileNotFoundException {
		JPanel panel = new JPanel();
		  
		panel.setLayout(new BorderLayout());
		  
		// Title for the component
		JLabel title = new JLabel("Flight Finder", SwingConstants.CENTER);
		title.setFont(new Font("serif", Font.PLAIN, 25));
		panel.add(title, BorderLayout.NORTH);
		  
		// Label of Fields for the component
		JPanel westPanel = new JPanel();
		westPanel.setLayout(new GridLayout(3,1));
		JLabel lFrom = new JLabel("From: ", SwingConstants.RIGHT);
		westPanel.add(lFrom);
		JLabel lTo = new JLabel("To: ", SwingConstants.RIGHT);
		westPanel.add(lTo);
		JLabel lDay = new JLabel("Day: ", SwingConstants.RIGHT);
		westPanel.add(lDay);

		panel.add(westPanel, BorderLayout.WEST);
		  
		// Fields for the component
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridLayout(3,1));
		tFrom = new JComboBox();
		populate_tFrom();
		centerPanel.add(tFrom);
		tTo = new JComboBox();
		populate_tTo();
		centerPanel.add(tTo);
		tDate = new JComboBox();
		populate_tDate();
		centerPanel.add(tDate);
		  
		panel.add(centerPanel, BorderLayout.CENTER);
		  
		// Find button
		findFlights = new JButton("Find Flights");
		panel.add(findFlights, BorderLayout.SOUTH);
		findFlights.addActionListener(this);
		  
		return panel;
		}
	/**
	 * Method to populate "from" combobox
	 * @throws FileNotFoundException for when file is not found
	 */
	private void populate_tFrom() throws FileNotFoundException
	{
		ArrayList<String> airports = flightManager.getAirports();
		for(int x = 0; x < airports.size(); x++)
		{
			String temp = airports.get(x);
			String code[] = temp.split(",");
			tFrom.addItem(code[0]);
		}
		
	}
	/**
	 * Method to populate "to" combobox
	 * @throws FileNotFoundException for when file is not found
	 */
	private void populate_tTo() throws FileNotFoundException
	{
		ArrayList<String> airports = flightManager.getAirports();
		for(int x = 0; x < airports.size(); x++)
		{
			String temp = airports.get(x);
			String code[] = temp.split(",");
			tTo.addItem(code[0]);

		}
		
	}
	/**
	 * Method to populate "date" combobox
	 */
	private void populate_tDate()
	{
		tDate.addItem(flightManager.WEEKDAY_ANY);
		tDate.addItem(flightManager.WEEKDAY_MONDAY);
		tDate.addItem(flightManager.WEEKDAY_TUESDAY);
		tDate.addItem(flightManager.WEEKDAY_WEDNESDAY);
		tDate.addItem(flightManager.WEEKDAY_THURSDAY);
		tDate.addItem(flightManager.WEEKDAY_FRIDAY);
		tDate.addItem(flightManager.WEEKDAY_SATURDAY);
		tDate.addItem(flightManager.WEEKDAY_SUNDAY);

	}
	/**
	 * Actions for listener
	 * @param e Action Event
	 */
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == findFlights)
		{
			flightsModel.clear();
			ArrayList<Flight> temp = flightManager.findFlights((String) tFrom.getSelectedItem(), (String) tTo.getSelectedItem(), (String) tDate.getSelectedItem());
			for(int x = 0; x < temp.size(); x++) {
				flightsModel.addElement(temp.get(x));
			}
		}
		
		if(e.getSource() == reserve)
		{
			try {
				reservationManager.makeReservation(flightsList.getSelectedValue(), tName.getText(), tCitizenship.getText());
				JOptionPane.showMessageDialog(null, "Reservation created. Your code is " +(reservationManager.getReservations().get(reservationManager.getReservations().size() - 1).getCode()));
			}
			catch(NoFlightException noflight)
			{
				JOptionPane.showMessageDialog(null, "No flight was selected");
			}
			catch (SeatsFullException seatsFull) 
			{
				JOptionPane.showMessageDialog(null, "Seats are full");
			}
			catch(EmptyInputException emptyInput)
			{
				JOptionPane.showMessageDialog(null, "No valid Name or Citizenship");
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(null, "No flight selected");
			}
			
			
				try {
					reservationManager.persist();
				} 
				catch (IOException fileError) {
					JOptionPane.showMessageDialog(null, "Unknown FileIOException");
					System.exit(0);
				}
		}
	}
}