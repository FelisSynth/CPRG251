/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

package sait.frms.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import sait.frms.manager.ReservationManager;
import sait.frms.problemdomain.Flight;
import sait.frms.problemdomain.Reservation;

/**
 * Holds the components for the reservations tab.
 * 
 */
public class ReservationsTab extends TabBase implements ActionListener{
	/**
	 * Instance of reservation manager.
	 */
	private ReservationManager reservationManager;
	private JList<Reservation> reservationsList;
	
	private DefaultListModel<Reservation> reservationsModel;
	
	/**
	* Fields and buttons for Find reservations component
	*/
	private JTextField tCode;
	private JTextField tAirline;
	private JTextField tName;
	private JButton findReservations;
	  
	/**
	* Fields and buttons for Update reservation
	*/
	private JButton update;
	private JTextField tCode1;
	private JTextField tFlight;
	private JTextField tAirline1;
	private JTextField tCost;
	private JTextField tName1;
	private JTextField tCitizenship;
	private JComboBox tStatus;
	
	/**
	 * Creates the components for reservations tab.
	 */
	public ReservationsTab(ReservationManager reservationManager) {
		this.reservationManager = reservationManager;
		panel.setLayout(new BorderLayout());
		
		JPanel northPanel = createNorthPanel();
		panel.add(northPanel, BorderLayout.NORTH);
		
		JPanel centerPanel = createCenterPanel();
		panel.add(centerPanel, BorderLayout.CENTER);
		
		JPanel eastPanel = createEastPanel();
		panel.add(eastPanel, BorderLayout.EAST);
		
		JPanel southPanel = createSouthPanel();
		panel.add(southPanel, BorderLayout.SOUTH);
	}
	
	/**
	 * Creates the north panel.
	 * @return JPanel that goes in north.
	 */
	private JPanel createNorthPanel() 
	{
		JPanel panel = new JPanel();
		
		JLabel title = new JLabel("Reservations", SwingConstants.CENTER);
		title.setFont(new Font("serif", Font.PLAIN, 29));
		panel.add(title);
		
		return panel;
	}
	/**
	 * Creates the center panel.
	 * @return JPanel that goes in center.
	 */
	private JPanel createCenterPanel()
	{
		JPanel panel = new JPanel();
		  
		panel.setLayout(new BorderLayout(10,10));
		  
		reservationsModel = new DefaultListModel<>();
		reservationsList = new JList<Reservation>(reservationsModel);
		  
		// User can only select one item at a time.
		reservationsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		  
		// Wrap JList in JScrollPane so it is scrollable.
		JScrollPane scrollPane = new JScrollPane(this.reservationsList);
		  
		reservationsList.addListSelectionListener(new MyListSelectionListener());
		  
		panel.add( scrollPane, BorderLayout.CENTER);
		  
		return panel;
		
		
		}
	
	/**
	 * Creates the east panel.
	 * @return JPanel that goes in east.
	 */
	private JPanel createEastPanel() 
	{
		JPanel panel = new JPanel();
		
		panel.setLayout(new BorderLayout(10,10));
		  
		// Title for the component
		JLabel title = new JLabel("Reserve", SwingConstants.CENTER);
		title.setFont(new Font("serif", Font.PLAIN, 25));
		panel.add(title, BorderLayout.NORTH);
		  
		JPanel GridLayout = new JPanel();
		GridLayout.setLayout(new GridLayout(7,2));
		  
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new FlowLayout());
		centerPanel.add(GridLayout);
		  
		// Fields and their label in Update reservation component
		JLabel lCode = new JLabel("Code: ", SwingConstants.RIGHT);
		tCode1 = new JTextField(10);
		tCode1.setEditable(false);
		GridLayout.add(lCode);
		GridLayout.add(tCode1);
		  
		JLabel lFlight = new JLabel("Flight: ", SwingConstants.RIGHT);
		tFlight = new JTextField(10);
		tFlight.setEditable(false);
		GridLayout.add(lFlight);
		GridLayout.add(tFlight);
		  
		JLabel lAirline = new JLabel("Airline: ",SwingConstants.RIGHT);
		tAirline1 = new JTextField(10);
		tAirline1.setEditable(false);
		GridLayout.add(lAirline);
		GridLayout.add(tAirline1);
		  
		JLabel lCost = new JLabel("Cost: ",SwingConstants.RIGHT);
		tCost = new JTextField(10);
		tCost.setEditable(false);
		GridLayout.add(lCost);
		GridLayout.add(tCost);
		  
		JLabel lName = new JLabel("Name: ",SwingConstants.RIGHT);
		tName1 = new JTextField(10);
		GridLayout.add(lName);
		GridLayout.add(tName1);
		  
		JLabel lCitizenship = new JLabel("Citizenship: ",SwingConstants.RIGHT);
		tCitizenship = new JTextField(10);
		GridLayout.add(lCitizenship);
		GridLayout.add(tCitizenship);
		  
		JLabel lStatus = new JLabel("Status: ",SwingConstants.RIGHT);
		String[] status = {"Active", "Inactive"};
		tStatus = new JComboBox(status);
		GridLayout.add(lStatus);
		GridLayout.add(tStatus);
		  
		panel.add(centerPanel, BorderLayout.CENTER);
		  
		// Update button
		update = new JButton("Update");
		panel.add(update, BorderLayout.SOUTH);
		update.addActionListener(this);
		
		return panel;
	}
	/**
	 * Creates the south panel.
	 * @return JPanel that goes in south.
	 */
	private JPanel createSouthPanel() 
	{
		JPanel panel = new JPanel();
		
		panel.setLayout(new BorderLayout());
		  
		// Title for the component
		JLabel title = new JLabel("Search", SwingConstants.CENTER);
		title.setFont(new Font("serif", Font.PLAIN, 25));
		panel.add(title, BorderLayout.NORTH);
		  
		// Label of Fields for the component
		JPanel westPanel = new JPanel();
		westPanel.setLayout(new GridLayout(3,1));
		JLabel lCode = new JLabel("Code: ", SwingConstants.RIGHT);
		westPanel.add(lCode);
		JLabel lAirline = new JLabel("Airline: ", SwingConstants.RIGHT);
		westPanel.add(lAirline);
		JLabel lName = new JLabel("Name: ", SwingConstants.RIGHT);
		westPanel.add(lName);
		  
		panel.add(westPanel, BorderLayout.WEST);
		  
		// Fields for the component
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridLayout(3,1));
		tCode = new JTextField();
		centerPanel.add(tCode);
		tAirline = new JTextField();
		centerPanel.add(tAirline);
		tName = new JTextField();
		centerPanel.add(tName);
		  
		panel.add(centerPanel, BorderLayout.CENTER);
		  
		// Find button
		findReservations = new JButton("Find Reservations");
		panel.add(findReservations, BorderLayout.SOUTH);
		findReservations.addActionListener(this);
		
		return panel;
	}
	/**
	 * Actions for listener
	 * @param e Action Event
	 */
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == findReservations)
		{
			reservationsModel.clear();
			ArrayList<Reservation> temp = reservationManager.findReservations(tCode.getText(), tAirline.getText(), tName.getText());
			for(int x = 0; x < temp.size(); x++)
			{
				reservationsModel.addElement(temp.get(x));
			}
		}
		
		if(e.getSource() == update) 
		{
			reservationsList.getSelectedValue().setName(tName1.getText());
			reservationsList.getSelectedValue().setCitizenship(tCitizenship.getText());
			
			if(tStatus.getSelectedIndex() == 0)
			{
				reservationsList.getSelectedValue().setActive(true);
			}
			else if(tStatus.getSelectedIndex() == 1)
			{
				reservationsList.getSelectedValue().setActive(false);
			}
			try {
				reservationManager.persist();
			} 
			catch (IOException fileError) {
				JOptionPane.showMessageDialog(null, "Unknown FileIOException");
				System.exit(0);
			}
			
		}
			
	}
	/**
	 * Listener for list selection
	 */
	private class MyListSelectionListener implements ListSelectionListener 
	{
		/**
		 * Called when user selects an item in the JList.
		 */
		@Override
		public void valueChanged(ListSelectionEvent e) {
			if(e.getSource() instanceof JList)
			{
			Reservation selectedReservation = reservationsList.getSelectedValue();
			tCode1.setText(selectedReservation.getCode());
			tFlight.setText(selectedReservation.getFlightCode());
			tAirline1.setText(selectedReservation.getAirline());
			tCost.setText("" + selectedReservation.getCost());
			tName1.setText(selectedReservation.getName());
			tCitizenship.setText(selectedReservation.getCitizenship());
			tStatus.setSelectedItem(selectedReservation.isActive());
			}	
		}
		
	}
	
}
