/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

package sait.frms.manager;

import java.io.*;
import java.util.*;

import javax.swing.JOptionPane;

import sait.frms.exception.WrongFormatException;
import sait.frms.problemdomain.Flight;

/**
 * Flight Manager class
 */
public class FlightManager
{
	public final String WEEKDAY_ANY = "Any";
	public final String WEEKDAY_SUNDAY = "Sunday";
	public final String WEEKDAY_MONDAY = "Monday";
	public final String WEEKDAY_TUESDAY = "Tuesday";
	public final String WEEKDAY_WEDNESDAY = "Wednesday";
	public final String WEEKDAY_THURSDAY = "Thursday";
	public final String WEEKDAY_FRIDAY = "Friday";
	public final String WEEKDAY_SATURDAY = "Saturday";
	private ArrayList<Flight> flights = new ArrayList<Flight>();
	private ArrayList<String> airports = new ArrayList<String>();
	
	/**
	 * Constructor for Flight Manager
	 * @throws FileNotFoundException for when file is not found
	 */
	public FlightManager() throws FileNotFoundException
	{
		try
		{
			populateAirports();
			populateFlights();
		}
		catch(WrongFormatException formatError)
		{
			JOptionPane.showMessageDialog(null, "Flight code format is incorrect please check your data.");
			System.exit(0);
		}
		catch(FileNotFoundException fileNotFound)
		{
			JOptionPane.showMessageDialog(null, "Could not find flights file Please make sure its in the correct location and closed");
			System.exit(0);
		}
	}
	/**
	 * Method to get airports
	 */
	public ArrayList<String> getAirports() 
	{
		return airports;
		
	}
	/**
	 * Method to get flights
	 */
	public ArrayList<Flight> getFlights() 
	{
		return flights;
		
	}
	/**
	 * Method to find airport by code
	 * @param code airport code
	 */
	public String findAirportByCode(String code)
	{
		for(int x = 0; x < airports.size(); x++)
		{
			String airportSplit[] = airports.get(x).split(",");
			
			if(airportSplit[0].equals(code))
			{
				return airportSplit[1];
			}
		}
		return "Error";
		
	}
	/**
	 * Method to find flight by code
	 * @param code flight code
	 */
	public Flight findFlightByCode(String code)
	{
		for(int x = 0; x < flights.size(); x++)
		{
			if(flights.get(x).getCode().equals(code))
			{
				return flights.get(x);
			}
		}
		return null;
		
	}
	/**
	 * Method to find flights
	 * @param from the From criteria
	 * @param to the To criteria
	 * @param weekday day of the week criteria
	 * @return list of matched flights
	 */
	public ArrayList<Flight> findFlights(String from, String to, String weekday)
	{
		ArrayList<Flight> foundFlights = new ArrayList<Flight>();
		for(int x = 0; x < flights.size(); x++)
		{
			if(weekday.equals(WEEKDAY_ANY))
			{
				if(flights.get(x).getFrom().equals(from) && flights.get(x).getTo().equals(to))
				{
					foundFlights.add(flights.get(x));
				}
			}
		
			else if(flights.get(x).getFrom().equals(from) && flights.get(x).getTo().equals(to) && (flights.get(x).getWeekday().equals(weekday)))
			{
				foundFlights.add(flights.get(x));
			}
		}
		return foundFlights;
		
	}
	/**
	 * Method to populate flight from database to arrayList
	 * @throws FileNotFoundException for when file is not found
	 * @throws WrongFormatException for when file entry format is wrong
	 */
	private void populateFlights() throws FileNotFoundException, WrongFormatException
	{
		Scanner scan = new Scanner(new File("res/flights.csv"));
		while(scan.hasNextLine())
		{
			String flightLine = scan.nextLine();
			String flightSection[] = flightLine.split(",");
			
			
			if(flightSection[0].length() == 7 && ((flightSection[0].charAt(0) >= 'A' && flightSection[0].charAt(0) <= 'Z') && (flightSection[0].charAt(1) >= 'A' && flightSection[0].charAt(1) <= 'Z')) && (flightSection[0].charAt(2) == '-') && ((flightSection[0].charAt(3) >= '0') && (flightSection[0].charAt(3) <= '9') && (flightSection[0].charAt(4) >= '0') && (flightSection[0].charAt(4) <= '9') && (flightSection[0].charAt(5) >= '0') && (flightSection[0].charAt(5) <= '9') && (flightSection[0].charAt(6) >= '0') && (flightSection[0].charAt(6) <= '9')))
			{
				Flight flight = new Flight(flightSection[0],flightSection[1],flightSection[2],flightSection[3],flightSection[4],flightSection[5], Integer.parseInt(flightSection[6]), Double.parseDouble(flightSection[7]));
				flights.add(flight);
			}
			else
			{
				throw new WrongFormatException("");
			}
			
		}
		scan.close();
		
	}
	/**
	 * Method to populate airport from database to arrayList
	 * @throws FileNotFoundException for when file is not found
	 */
	private void populateAirports() throws FileNotFoundException 
	{
		 File airportFile = new File("res/airports.csv");
	        Scanner airportFileReader = new Scanner(airportFile);

	        while(airportFileReader.hasNextLine()) {
	            String airport = airportFileReader.nextLine();
	            airports.add(airport);
	        }
	        airportFileReader.close();
	}
	
}
