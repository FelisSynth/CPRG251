/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

package sait.frms.manager;

import java.io.*;
import java.util.*;

import javax.swing.JOptionPane;

import sait.frms.exception.EmptyInputException;
import sait.frms.exception.NoFlightException;
import sait.frms.exception.WrongFormatException;
import sait.frms.exception.SeatsFullException;
import sait.frms.problemdomain.Flight;
import sait.frms.problemdomain.Reservation;

/**
 * Reservation manager class
 */
public class ReservationManager
{

	private ArrayList<Reservation> reservations = new ArrayList<Reservation>();
	/**
	 * Constructor for reservation manager
	 */
	public ReservationManager() throws IOException 
	{
		try
		{
			populateFromBinary();
		}
		catch(WrongFormatException formtError)
		{
			JOptionPane.showMessageDialog(null, "Reservation code format is incorrect please check your data.");
			System.exit(0);
		}
		catch(FileNotFoundException fileNotFound)
		{
			JOptionPane.showMessageDialog(null, "Could not find reservations file Please make sure its in the correct location and closed");
			System.exit(0);
		}
		finally
		{
			persist();
		}
		
	}
	/**
	 * method to make reservation
	 * @param flight flight
	 * @param name name
	 * @param citizenship citizenship
	 * @return Reservation object
	 * @throws Exception Exception
	 */
	public Reservation makeReservation(Flight flight, String name, String citizenship) throws Exception
	{
		String reservationCode = generateReservationCode(flight);
		Reservation reservation = null;
		if(getAvailableSeats(flight) < 1)
		{
			throw new SeatsFullException("");
		}
		if(flight.equals(null))
		{
			throw new NoFlightException("");
		}
		if((name.equals("") || name.equals(null) )|| (citizenship.equals("") || citizenship.equals(null)))
		{
			throw new EmptyInputException("");
		}
		else
		{
			reservation = new Reservation(reservationCode, flight.getCode(), flight.getAirlineName(), name, citizenship, flight.getCostPerSeat(), true);
			reservations.add(reservation);
		}
		return reservation;
		
	}
	/**
	 * Method to find reservations
	 * @param code code
	 * @param airline air line
	 * @param name name
	 * @return list of reservations
	 */
	public ArrayList<Reservation> findReservations(String code, String airline,String name)
	{
		ArrayList<Reservation> reservationsFilter = new ArrayList<Reservation>();
		for(int x = 0; x < reservations.size(); x++)
		{
			if(reservations.get(x).getCode().equals(code) || reservations.get(x).getAirline().equals(airline) || reservations.get(x).getName().equals(name))
			{
				reservationsFilter.add(reservations.get(x));
			}
		}
		return reservationsFilter;
		
	}
	/**
	 * Method to find reservation by code
	 * @param code code
	 * @return Reservation object
	 */
	public Reservation findReservationByCode(String code)
	{
		for(int x = 0; x < reservations.size(); x++)
		{
			if(reservations.get(x).getCode().equals(code))
			{
				return reservations.get(x);
			}
		}
		return null;
		
	}
	/**
	 * Method to write changes to file
	 * @throws IOException Input/Output Exception
	 */
	public void persist() throws IOException
	{
		RandomAccessFile file = new RandomAccessFile(new File("res/Reservation.csv"),"rw");
		for(int x = 0; x < reservations.size(); x ++)
		{
			String csvFormat = reservations.get(x).getCode() + ",";
			csvFormat += reservations.get(x).getFlightCode() + ",";
			csvFormat += reservations.get(x).getAirline() + ",";
			csvFormat += reservations.get(x).getName() + ",";
			csvFormat += reservations.get(x).getCitizenship() + ",";
			csvFormat += reservations.get(x).getCost() + ",";
			csvFormat += reservations.get(x).isActive() + "\n";
			file.writeBytes(csvFormat);
		}
		
	}
	/**
	 * Method to get available seats
	 * @param flight flight object
	 * @return int of seat number
	 */
	private int getAvailableSeats(Flight flight)
	{
		int availableSeats = flight.getSeats();
		
		for(int x = 0; x < reservations.size(); x++)
		{
			if(reservations.get(x).getCode().equals(flight.getCode()))
			{
				availableSeats--;
				flight.setSeats(availableSeats);
			}
		}
		return flight.getSeats();
		
	}
	/**
	 * Method to generate reservation code
	 * @param flight flight object
	 * @return string of reservation code
	 */
	private String generateReservationCode(Flight flight) 
	{
		String code = "";
		if(flight.getFrom().charAt(0) == 'Y' && flight.getTo().charAt(0) == 'Y')
		{
			code+="D";
		}
		else
		{
			code+="I";
		}
		code += ((int)(Math.random() * (9999 + 1001)));
		return code;
		
	}
	/**
	 * Method to populate reservation list from file
	 * @throws IOException Input/Output Exception
	 * @throws WrongFormatException exception to check format
	 */
	private void populateFromBinary() throws IOException, WrongFormatException 
	{
		RandomAccessFile file = new RandomAccessFile(new File("res/Reservation.csv"),"rw");
		String line;
		while((line = file.readLine()) != null)
		{
			String lineSection[] = line.split(",");
			if((lineSection[0].length() == 5) && ((lineSection[0].charAt(0) == 'D' || lineSection[0].charAt(0) == 'I')) && ((lineSection[0].charAt(1) >= '0' && lineSection[0].charAt(1) <= '9') && (lineSection[0].charAt(2) >= '0' && lineSection[0].charAt(2) <= '9') && (lineSection[0].charAt(3) >= '0' && lineSection[0].charAt(3) <= '9') && (lineSection[0].charAt(4) >= '0' && lineSection[0].charAt(4) <= '9')) )
			{
				Reservation reservation = new Reservation(lineSection[0], lineSection[1], lineSection[2], lineSection[3], lineSection[4], Double.parseDouble(lineSection[5]), Boolean.parseBoolean(lineSection[6]));
				reservations.add(reservation);
			}
			else
			{
				throw new WrongFormatException("");
			}
			
			
		}
		file.close();
	}
	/**
	 * Method to get reservation
	 * @return list of reservations
	 */
	public ArrayList<Reservation> getReservations()
	{
		return reservations;
	}
	
}
