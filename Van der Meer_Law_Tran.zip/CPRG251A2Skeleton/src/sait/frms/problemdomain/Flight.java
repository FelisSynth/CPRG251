/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

package sait.frms.problemdomain;

/**
 * Flight class
 */
public class Flight {
	private String code;
	private String airlineName;
	private String from;
	private String to;
	private String weekday;
	private String time;
	private int seats;
	private double costPerSeat;
	
	/**
	 * Constructor for flight object
	 * @param code flight code
	 * @param airlineName airline name
	 * @param from from
	 * @param to to
	 * @param weekday day of the week
	 * @param time flight time
	 * @param seats number of available seats
	 * @param costPerSeat cost per seat
	 */
	public Flight(String code, String airlineName, String from, String to, String weekday, String time, int seats, double costPerSeat)
	{
	this.code = code;
	this.airlineName = airlineName;
	this.from = from;
	this.to = to;
	this.weekday = weekday;
	this.time = time;
	this.seats = seats;
	this.costPerSeat = costPerSeat;
	}

	/**
	 * Method to get flight code
	 * @return flight code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * Method to set flight code
	 * @param code flight code
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * Method to get airline name
	 * @return airline name
	 */
	public String getAirlineName() {
		return airlineName;
	}
	/**
	 * Method to set airline name
	 * @param airlineName airline name
	 */
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}
	/**
	 * Method to get "from" factor
	 * @return from
	 */
	public String getFrom() {
		return from;
	}
	/**
	 * Method to set "from" factor
	 * @param from "from" factor
	 */
	public void setFrom(String from) {
		this.from = from;
	}
	/**
	 * Method to get "to" factor
	 * @return to
	 */
	public String getTo() {
		return to;
	}
	/**
	 * Method to set "to" factor
	 * @param to "to" factor
	 */
	public void setTo(String to) {
		this.to = to;
	}
	/**
	 * Method to get weekday
	 * @return weekday
	 */
	public String getWeekday() {
		return weekday;
	}
	/**
	 * Method to set weekday
	 * @param weekday weekday
	 */
	public void setWeekday(String weekday) {
		this.weekday = weekday;
	}
	/**
	 * Method to get flight time
	 * @return flight time
	 */
	public String getTime() {
		return time;
	}
	/**
	 * Method to set flight time
	 * @param time flight time
	 */
	public void setTime(String time) {
		this.time = time;
	}
	/**
	 * Method to get number of seats available
	 * @return number of seats
	 */
	public int getSeats() {
		return seats;
	}
	/**
	 * Method to set seats available
	 * @param seats seats available
	 */
	public void setSeats(int seats) {
		this.seats = seats;
	}
	/**
	 * Method to get cost per seat
	 * @return cost per seat
	 */
	public double getCostPerSeat() {
		return costPerSeat;
	}
	/**
	 * Method to set cost per seat
	 * @param costPerSeat cost per seat
	 */
	public void setCostPerSeat(double costPerSeat) {
		this.costPerSeat = costPerSeat;
	}
	/**
	 * Method to indicate is domestic
	 * @return false
	 */
	public boolean isDomestic()
	{
		return false;
		
	}
	/**
	 * Method to get string display of flight
	 * @return string display of flight
	 */
	public String toString() {
		return code + ", From: " + from + ", To: " + to + ", Day: " + weekday + ", Cost: " + costPerSeat;
	}
	
	
	
	
}
