/**
 * @author Dylano van der Meer
 * @author Joshua Law
 * @author Trung Hieu Tran
 */

package sait.frms.problemdomain;

public class Reservation {
private String code;
private String flightCode;
private String airline;
private String name;
private String citizenship;
private double cost;
private boolean active;

public Reservation(String code, String flightCode, String airline, String name, String citizenship, double cost, boolean active) {
this.code = code;
this.flightCode = flightCode;
this.airline = airline;
this.name = name;
this.citizenship = citizenship;
this.cost = cost;
this.active = active;
}

/**
 * Method to get flight code
 * @return flight code
 */
public String getCode() {
	return code;
}
/**
 * Method to set flight code
 * @param code flight code
 */
public void setCode(String code) {
	this.code = code;
}
/**
 * Method to get flight code
 * @return flight code
 */
public String getFlightCode() {
	return flightCode;
}
/**
 * Method to set flight code
 * @param code flight code
 */
public void setFlightCode(String flightCode) {
	this.flightCode = flightCode;
}
/**
 * Method to get airline name
 * @return airline name
 */
public String getAirline() {
	return airline;
}
/**
 * Method to set airline 
 * @param airlineName airline
 */
public void setAirline(String airline) {
	this.airline = airline;
}
/**
 * Method to get name
 * @return name
 */
public String getName() {
	return name;
}
/**
 * Method to set name
 * @param name name
 */
public void setName(String name) {
	this.name = name;
}
/**
 * Method to get citizenship
 * @return citizenship
 */
public String getCitizenship() {
	return citizenship;
}
/**
 * Method to set citizenship
 * @param citizenship citizenship
 */
public void setCitizenship(String citizenship) {
	this.citizenship = citizenship;
}
/**
 * Method to get cost
 * @return cost
 */
public double getCost() {
	return cost;
}
/**
 * Method to set cost
 * @param cost cost
 */
public void setCost(double cost) {
	this.cost = cost;
}
/**
 * Method to get active status
 * @return active status
 */
public boolean isActive() {
	return active;
}
/**
 * Method to set active status
 * @param active active status
 */
public void setActive(boolean active) {
	this.active = active;
}

/**
 * Method to get string display of reservation
 * @return string display of reservation
 */
public String toString() {
	return "Reservation [code=" + code + ", flightCode=" + flightCode + ", airline=" + airline + ", name=" + name
			+ ", citizenship=" + citizenship + ", cost=" + cost + ", active=" + active + "]";
}



}
